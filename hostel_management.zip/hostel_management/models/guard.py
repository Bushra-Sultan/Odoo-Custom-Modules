from odoo import fields, models, api


class securityguard(models.Model):
    _name = "hostel.guard"
    _description = "guard"

    name = fields.Char(string='Name', tracking=True)
    email = fields.Char(string='Email')
    address = fields.Char(string='Address')
    date_of_birth = fields.Date(string="DOB")
    contact = fields.Char(string="Mobile Number", tracking=True)
    is_guard = fields.Boolean(string='guard', default=True)
    hiring_date = fields.Date(string="Hire Date")
    qualification = fields.Char(string='Qualification')
    guard_id = fields.Many2one('hostel.student', 'guard_id')

