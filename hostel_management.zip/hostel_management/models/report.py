from odoo import api, fields, models


class WHStockReport(models.AbstractModel):
    _name = 'report.hostel_management.booking_room'

    @api.model
    def _get_report_values(self, docids=None, data=None):
        if data is None:
            data = {}
        date_from = data.get('date_from')
        date_to = data.get('date_to')
        records = self.env['student.room'].search([('id', 'in', data.get('student_ids'))])
        return {
            'date_from': date_from,
            'date_to': date_to,
            'student_id': records
        }



