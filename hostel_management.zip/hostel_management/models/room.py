from odoo import fields, models, api


class hostel(models.Model):
    _description = "students"
    _name = "student.room"
    name = fields.Char(string='Student Name', required=True)
    number = fields.Integer(string='Room Number')
    block = fields.Char(string='Block')
    hostel_id = fields.Many2one('hostel.student')
    student_id = fields.Many2one('student.bed')

    def action_share_whatsapp(self):
        whatsapp_api_url = 'http://api.whatsapp.com/send'
        return {
            'type': 'ir.actions.act_url',
            'target': 'new',
            'url': whatsapp_api_url
        }
