from odoo import fields, models


class hostelstudents(models.Model):
    _name = "hostel.student"
    _description = "Students"

    # _rec_name = 'session_id'

    bed_id = fields.Many2one('student.bed', string="Bed")
    guard_id = fields.Many2many('hostel.guard', string="Guard")
    hostel_line_id = fields.One2many('hostel.room', 'hostel_id', string="Students")


class HostelRoom(models.Model):
    _name = 'hostel.room'
    _description = "Student Room"
    room_id = fields.Many2one('student.room', string="Rooms")
    hostel_id = fields.Many2one('hostel.student', string="Hostel Student")
