from odoo import fields, models, api


class hostel(models.Model):
    _description = "students"
    _name = "student.bed"
    # name = fields.Char(string='Student Name', required=True)
    number = fields.Char(string='Bed Number')
    bed_id = fields.Many2one('hostel.student', 'bed_id')
    student_id = fields.Many2one('student.room', string='Student')  # Assuming 'res.partner' for student records

