from odoo import models, fields, api


class HostelAdminWizard(models.TransientModel):
    _name = 'hostel.admin.wizard'
    _description = 'Hostel Administration Wizard'

    from_date = fields.Date(string='From Date')
    to_date = fields.Date(string='To Date')
    student_id = fields.Many2many(
        'student.room',
        string='Student')

    def _default_room_ids(self):
        return self.env['student.room'].search([]).ids

    def print_report(self):
        data = {
            'form': self.read()[0],
            'student_ids': self.student_id.ids,
            'date_from': self.from_date,
            'date_to': self.to_date,
        }
        return self.env.ref('hostel_management.action_report_student_room').report_action(self, data=data)

    def action_cancel(self):
        return {'type': 'ir.actions.act_window_close'}
