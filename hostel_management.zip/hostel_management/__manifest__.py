# -*- coding: utf-8 -*-

{
    'name': "Hostel Management",
    'summary': "Module for managing hostel operations.",
    'sequence': 10,
    'author': "Bushra",
    'version': '0.1',
    'application': True,

    'depends': ['base', 'mail', 'stock'],

    # always loaded
    'data': [
        'security/ir.model.access.csv',
        'views/menu.xml',
        'views/room.xml',
        'wizard/admin.xml',
        "reports/report.xml",
        "reports/booking_room.xml",
        'views/bed.xml',
        'views/guard.xml',
        'views/student.xml',
    ],
}
