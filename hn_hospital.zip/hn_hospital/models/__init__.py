from .import patient
from .import appointment
from .import res_config_settings
from .import operation
from .import patient_card_xls
